﻿namespace shared
{
    /**
     * Sent from CLIENT 2 SERVER.
     */
    public class GetRequest : ISerializable
    {
        public void Serialize(Packet pPacket)   {}
        public void Deserialize(Packet pPacket) {}
    }
}
